﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigment_2
{
    public class Flight
    {
        public string FlightCode { get; set; }
        public string Airline { get; set; }
        public DayOfWeek Day { get; set; }
        public TimeSpan Time { get; set; }
        public decimal Cost { get; set; }

        public override string ToString()
        {
            return $"{FlightCode} - {Airline} - {Day} - {Time} - ${Cost}";
        }
    }
