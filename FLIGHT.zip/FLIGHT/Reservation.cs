﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLIGHT
{
    public class Reservation
    {
        public string Code { get; set; }
        public Flight FlightDetails { get; set; }
        public string TravelerName { get; set; }
        public string Citizenship { get; set; }
        public bool IsActive { get; set; }

        public Reservation(string code, Flight flightDetails, string travelerName, string citizenship, bool isActive = true)
        {
            Code = code;
            FlightDetails = flightDetails;
            TravelerName = travelerName;
            Citizenship = citizenship;
            IsActive = isActive;
        }

        public override string ToString()
        {
            return $"{Code} - {TravelerName}, {Citizenship} on {FlightDetails}";
        }
    }
}
