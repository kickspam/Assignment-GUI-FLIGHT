﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLIGHT
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;

    public class ReservationManager
    {
        private List<Flight> flights = new List<Flight>();
        private List<Reservation> reservations = new List<Reservation>();
        private string flightsFilePath = @"C:\Users\Sam\source\repos\FLIGHT\flights.csv";
        private string reservationsFilePath = @"C:\Users\Sam\source\repos\FLIGHT\reservations.csv";

        public ReservationManager()
        {
            LoadFlightsFromFile();
            LoadReservationsFromFile();
        }

        private void LoadFlightsFromFile()
        {
            var lines = File.ReadAllLines(flightsFilePath);
            foreach (var line in lines.Skip(1)) // Skipping header row
            {
                var parts = line.Split(',');
                var flight = new Flight(
                    parts[0], // FlightNumber
                    parts[1], // Airline
                    parts[2], // Origin
                    parts[3], // Destination
                    parts[4], // DayOfWeek
                    TimeSpan.Parse(parts[5]), // DepartureTime
                    double.Parse(parts[6], CultureInfo.InvariantCulture) // Cost
                );
                flights.Add(flight);
            }
        }

        private void LoadReservationsFromFile()
        {
            var lines = File.ReadAllLines(reservationsFilePath);
            foreach (var line in lines.Skip(1)) // Skipping header row
            {
                var parts = line.Split(',');
                var flight = flights.FirstOrDefault(f => f.FlightNumber == parts[1]);
                if (flight != null)
                {
                    var reservation = new Reservation(
                        parts[0], // Code
                        flight,
                        parts[2], // TravelerName
                        parts[3], // Citizenship
                        bool.Parse(parts[4]) // IsActive
                    );
                    reservations.Add(reservation);
                }
            }
        }

        public void SaveReservationsToFile()
        {
            var lines = new List<string> { "Code,FlightNumber,TravelerName,Citizenship,IsActive" }; // Header
            foreach (var reservation in reservations)
            {
                lines.Add($"{reservation.Code},{reservation.FlightDetails.FlightNumber},{reservation.TravelerName},{reservation.Citizenship},{reservation.IsActive}");
            }
            File.WriteAllLines(reservationsFilePath, lines);
        }

        // Implement other methods (FindFlights, MakeReservation, etc.) here
    }

}
