﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FLIGHT
{
    using System;
    using System.Globalization;

    public class Flight
    {
        public string FlightNumber { get; private set; }
        public string Airline { get; private set; }
        public string Origin { get; private set; }
        public string Destination { get; private set; }
        public string DayOfWeek { get; private set; }
        public TimeSpan DepartureTime { get; private set; }
        public double Cost { get; private set; }

        public Flight(string flightNumber, string airline, string origin, string destination, string dayOfWeek, TimeSpan departureTime, double cost)
        {
            FlightNumber = flightNumber;
            Airline = airline;
            Origin = origin;
            Destination = destination;
            DayOfWeek = dayOfWeek;
            DepartureTime = departureTime;
            Cost = cost;
        }

        public override string ToString()
        {
            // Customize this method to display flight information in a format you prefer
            return $"{FlightNumber} - {Airline} from {Origin} to {Destination}, {DayOfWeek} at {DepartureTime.ToString(@"hh\:mm", CultureInfo.InvariantCulture)} for ${Cost}";
        }
    }
}
