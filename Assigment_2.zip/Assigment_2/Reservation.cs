﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assigment_2
{
    public class Reservation
    {
        public string ReservationCode { get; set; }
        public Flight FlightDetails { get; set; }
        public string Name { get; set; }
        public string Citizenship { get; set; }
        public bool IsActive { get; set; } = true;

        public override string ToString()
        {
            return $"{ReservationCode} - {FlightDetails.FlightCode} - {Name} - {Citizenship} - {(IsActive ? "Active" : "Inactive")}";
        }
    }
}