﻿using Assigment_2;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

public class ReservationManager
{
    private List<Flight> flights = new List<Flight>();
    private List<Reservation> reservations = new List<Reservation>();

    private const string FlightsFilePath = @"C:\Users\Sam\source\repos\Assigment_2\flights.csv";
    private const string ReservationsFilePath = @"C:\Users\Sam\source\repos\Assigment_2\reservations.csv";

    public void LoadData()
    {
        LoadFlightsFromFile();
        LoadReservationsFromFile();
    }

    private void LoadFlightsFromFile()
    {
        if (!File.Exists(FlightsFilePath))
        {
            throw new FileNotFoundException("Flights file not found.", FlightsFilePath);
        }

        var lines = File.ReadAllLines(FlightsFilePath);
        foreach (var line in lines.Skip(1)) // Assuming the first line is headers
        {
            var parts = line.Split(',');
            var flight = new Flight
            {
                FlightCode = parts[0].Trim(),
                Airline = parts[1].Trim(),
                Day = Enum.Parse<DayOfWeek>(parts[2].Trim(), true),
                Time = TimeSpan.ParseExact(parts[3].Trim(), "hh\\:mm", CultureInfo.InvariantCulture),
                Cost = decimal.Parse(parts[4].Trim(), CultureInfo.InvariantCulture)
            };

            flights.Add(flight);
        }
    }

    private void LoadReservationsFromFile()
    {
        if (!File.Exists(ReservationsFilePath))
        {
            throw new FileNotFoundException("Reservations file not found.", ReservationsFilePath);
        }

        var lines = File.ReadAllLines(ReservationsFilePath);
        foreach (var line in lines.Skip(1)) // Assuming the first line is headers
        {
            var parts = line.Split(',');
            var reservation = new Reservation
            {
                ReservationCode = parts[0].Trim(),
                FlightDetails = flights.FirstOrDefault(f => f.FlightCode == parts[1].Trim()), // Find the associated flight
                Name = parts[2].Trim(),
                Citizenship = parts[3].Trim(),
                IsActive = bool.Parse(parts[4].Trim())
            };

            reservations.Add(reservation);
        }
    }

    // Placeholder for additional methods like FindFlights, MakeReservation, etc.
}
