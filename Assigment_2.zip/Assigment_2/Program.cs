﻿namespace Assigment_2
{
    using System;

    using System;

    namespace Assigment_2    {
        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Travel Agency Reservation System Started");

                var reservationManager = new ReservationManager();
                reservationManager.LoadData(); // Load flights and reservations from CSV files

                // Placeholder for GUI event loop in a real application
            }
        }
    }
